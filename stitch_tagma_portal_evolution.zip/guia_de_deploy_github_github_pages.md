# Guia de Hospedagem: Portal TAGMA no GitHub

Este guia explica como hospedar o seu novo portal de notícias de forma gratuita utilizando o **GitHub Pages**, eliminando custos de mensalidade e garantindo alta performance.

---

## 1. Preparação Inicial
Antes de começar, você precisará:
*   Uma conta gratuita no [GitHub](https://github.com).
*   Os arquivos do site (o código HTML/CSS que estamos desenvolvendo).
*   Seu domínio registrado (ex: `tagma.com.br`).

---

## 2. Criando o Repositório
O "Repositório" é onde os arquivos do seu site ficarão guardados.
1.  Acesse seu GitHub e clique no botão **"+"** (canto superior direito) > **New repository**.
2.  **Repository name:** Escolha um nome (ex: `portal-tagma`).
3.  **Public:** Certifique-se de que está marcado como Público.
4.  Clique em **Create repository**.

---

## 3. Subindo os Arquivos
1.  Na página do repositório, clique em **"uploading an existing file"**.
2.  Arraste todos os arquivos do site (o `index.html` e as pastas de imagens/estilos) para a área indicada.
3.  No campo "Commit changes", escreva algo como "Primeira versão do TAGMA".
4.  Clique em **Commit changes**.

---

## 4. Ativando o Site (GitHub Pages)
1.  Vá na aba **Settings** (Configurações) do seu repositório.
2.  No menu lateral esquerdo, clique em **Pages**.
3.  Em "Build and deployment", confirme se o "Source" está como **Deploy from a branch**.
4.  Em "Branch", selecione `main` (ou `master`) e a pasta `/(root)`.
5.  Clique em **Save**.
6.  *Aguarde cerca de 2 minutos.* O GitHub exibirá um link como `https://seu-usuario.github.io/portal-tagma/`. Seu site já estará no ar!

---

## 5. Configurando seu Domínio (.com.br)
Para usar o seu endereço próprio e não o link do GitHub:
1.  Ainda na tela de **Pages**, vá em **Custom domain**.
2.  Digite seu domínio (ex: `www.tagma.com.br`) e clique em **Save**.
3.  **DNS (No seu registrador de domínio):** Você precisará criar um registro do tipo `CNAME` apontando para `seu-usuario.github.io`.
4.  Marque a opção **Enforce HTTPS** no GitHub para garantir que o site seja seguro (cadeado verde).

---

## Próximos Passos
Agora que você tem o guia, podemos:
1.  Finalizar a versão **Desktop** do portal.
2.  Criar o seu **Painel Administrativo (CMS)** para você publicar notícias sem precisar mexer em código.

**Deseja que eu comece a versão Desktop agora?**